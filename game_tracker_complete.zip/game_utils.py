from csv import DictReader, DictWriter


def write_titles_to_file(file_path, games):
    """Write all game titles to a text file, overwriting existing content."""
    with open(file_path, "w") as f:
        for game in games:            
            f.write(f"{game["title"]}\n")

def append_title_to_file(file_path, title):
    """Append one game title to the text file."""
    with open(file_path, "a") as f:
        f.write(f"{title}\n")

def read_titles_from_file(file_path):
    """Read all titles from a text file and return them as a list."""
    titles = []
    with open(file_path, "r") as f:
        for line in f:
            titles.append(line.strip())#remove the \n from the string on the file before adding to the list
    return titles

def get_completed_games(games):
    """Return a list containing only completed games."""
    completed_games = []
    for game in games:
        if game["completed"] == "Yes":
            completed_games.append(game)
    return completed_games

def write_games_to_csv(file_path, games):
    """Write a list of game dictionaries to a CSV file."""
    with open(file_path, "w", newline="") as f:#newline = "" prevents extra the extra line return. It says for a newline let the dictionaryWriter handle it.         
        writer = DictWriter(f, fieldnames=["title", "platform", "rating", "completed"])
        writer.writeheader()        
        writer.writerows(games)#write all the rows in the games dictionary to the file. writerow() writes a single row.

def read_games_from_csv(file_path):
    """Read game data from a CSV file into a list of dictionaries."""
    games = []
    with open(file_path, "r") as f:
        reader = DictReader(f)
        for row in reader:
            games.append(row)
    return games
