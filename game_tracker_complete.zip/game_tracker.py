from pathlib import Path
from game_utils import *


if __name__ == "__main__":#if we are running this file directly then this is no necessary. However, good defensive programming would be to include. In the future someone might import this file so better safe than sorry. 
    base_dir = Path(__file__).parent#get the directory of the folder this file is in

    text_file = base_dir / "games.txt"#path to the games.txt file (contains the game titles)
    csv_file = base_dir / "games.csv"#path to the games.csv file (contains the games)
    completed_csv_file = base_dir / "completed_games.csv" #path to the completed_games.csv (contains the completed games)
   
    #Part A – Lists and Dictionaries
    #Create a list of at least 5 games (dictionaries). See games.csv for the keys.
    games = [
        {"title": "Zelda: Breath of the Wild", "platform": "Switch", "rating": 10, "completed": "Yes"},
        {"title": "Minecraft", "platform": "PC", "rating": 9, "completed": "No"},
        {"title": "God of War", "platform": "PlayStation", "rating": 9, "completed": "Yes"},
        {"title": "Mario Kart 8", "platform": "Switch", "rating": 8, "completed": "No"},
        {"title": "Stardew Valley", "platform": "PC", "rating": 10, "completed": "Yes"},
    ]
    #Print all games as dictionaries.
    print("All games:")
    for game in games:
        print(game)

    #Print titles and ratings.
    print("\nTitles and ratings:")
    for game in games:
        print(f"{game["title"]} - Rating: {game["rating"]}")

    #Part B – Text File I/O
    # Use your functions to write titles to games.txt.
    write_titles_to_file(text_file, games)

    #Append a new title entered by the user.    
    new_title = input("\nEnter a new game title: ").strip()
    while not new_title:# If the user does not enter a title loop until they do
        new_title = input("Please enter a game title: ").strip()

    append_title_to_file(text_file, new_title)

    # Read and display all titles.
    print("\nGames in text file:")
    titles = read_titles_from_file(text_file)
    for title in titles:
        print(title)

    # Part C – CSV File I/O
    # Write all game data to games.csv.
    write_games_to_csv(csv_file, games)

    #Read games.csv into a list of dictionaries.
    game_data = read_games_from_csv(csv_file)

    # Use your function to filter completed games into another list.
    completed_games = get_completed_games(game_data)

    #Print the titles of the completed games
    print("\nCompleted games:")
    for game in completed_games:
        print(game["title"])

    #Part D – Filtered CSV
    # Write completed games to completed_games.csv.
    write_games_to_csv(completed_csv_file, completed_games)

